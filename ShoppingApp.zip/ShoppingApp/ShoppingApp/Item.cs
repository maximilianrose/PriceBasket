﻿namespace ShoppingApp
{
    internal class Item
    {
        public string? ItemName { get; set; }

        public decimal? Price { get; set; }
    }
}