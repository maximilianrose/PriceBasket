﻿// See https://aka.ms/new-console-template for more information

using ShoppingApp;


//Build list of valid items to put in basket
List<Item> ItemsForSale = new List<Item>();

Item Beans = new Item();
Beans.ItemName = "beans";
Beans.Price = 0.98m;

ItemsForSale.Add(Beans);

Item Bread = new Item();
Bread.ItemName = "bread";
Bread.Price = 0.84m;

ItemsForSale.Add(Bread);

Item Milk = new Item();
Milk.ItemName = "milk";
Milk.Price = 1.50m;

ItemsForSale.Add(Milk);

Item Oranges = new Item();
Oranges.ItemName = "oranges";
Oranges.Price = 1.90m;

ItemsForSale.Add(Oranges);

Console.WriteLine("Welcome to the shopping app, to start, please type 'PriceBasket' followed by the list of items you'd like to purchase, each separated by a space");

string? Input = Console.ReadLine();

List<string> GetItems = new List<string>();
List<Item> ItemsChosen = new List<Item>();

if (Input != null)
{
    //build list of words in user's string

    GetItems = Input.Split(' ').ToList();
}

if (GetItems != null)
{
    if (GetItems.ElementAt(0).ToLower() == "pricebasket")

    {
        foreach (string? item in GetItems)

        {
            foreach (Item item1 in ItemsForSale)
            {
                if (item.ToLower() == item1.ItemName)
                {
                    ItemsChosen.Add(item1);
                }
            }
        }
    }
}

decimal OrangesSavings = 0;
decimal BeansSavings = 0;

if (ItemsChosen.Count > 0)
{
    //count up the discounts on oranges

    foreach (Item item in ItemsChosen)
    {
        if (item.ItemName == "oranges")

        {
            Item Product = ItemsForSale.Find(product => product.ItemName == "oranges");

            decimal Savings = (decimal)(Product.Price * 0.2m);

            OrangesSavings = OrangesSavings + Savings;
        }
    }

    int NumberOfBeans = 0;
    int NumberOfBreads = 0;

    foreach (Item item1 in ItemsChosen)
    {
        if (item1.ItemName == "beans")

        {
            NumberOfBeans++;
        }

        if (item1.ItemName == "bread")

        {
            NumberOfBreads++;
        }
    }

    if (NumberOfBeans >= 2 && NumberOfBreads >= 1)

    {
        //work out maximum number of discounted loaves of bread by dividing the number of beans by 2

        int MaxNumberOfDiscountBreads = NumberOfBeans / 2;

        Item Product = ItemsForSale.Find(product => product.ItemName == "bread");

        decimal Savings = 0m;

        //if number of loaves of bread is smaller than the maximum, discount all in the basket

        if (NumberOfBreads < MaxNumberOfDiscountBreads)

        {
            BeansSavings = (decimal)(BeansSavings + ((Product.Price * 0.5m) * NumberOfBreads));
        }
        else
        {
            BeansSavings = (decimal)(BeansSavings + ((Product.Price * 0.5m) * MaxNumberOfDiscountBreads));
        }
    }

    //Add up totals and subtotals here

    if (ItemsChosen.Count > 0)

    {
        decimal subtotal = 0;

        foreach (Item item in ItemsChosen)

        {
            subtotal = (decimal)(subtotal + item.Price);
        }

        foreach (Item item in ItemsChosen)
        {
            Console.WriteLine(item.ItemName + ", £" + item.Price.ToString());
        }

        Console.WriteLine("SubTotal: £" + subtotal.ToString());

        if (OrangesSavings == 0 & BeansSavings == 0)

        {
            Console.WriteLine("(no offers available)");
        }

        if (OrangesSavings > 0)

        {
            Console.WriteLine("Oranges 20% off -£" + OrangesSavings.ToString());
        }

        if (BeansSavings > 0)
        {
            Console.WriteLine("Multibuy Offer: 2 tins of beans, 50% off a loaf of bread -£" + BeansSavings.ToString());
        }

        decimal Total = subtotal - BeansSavings - OrangesSavings;

        Console.WriteLine("Total: £" + Total.ToString());
    }
    else
    {
        Console.WriteLine("Invalid Input");
    }
}